# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.


import os
import subprocess

def execute_command(command, env_params=None, cwd=None):
    """
    Executes the given command string with given environment parameters
    :param str command: Command with arguments to be executed
    :param dict[str, str] env_params: Environment variables to be used
    :return: output and error string tuple, RuntimeError if errors occur
    :rtype: tuple
    :exception: RuntimeError
    """
    os_env = os.environ.copy()
    if env_params is not None:
        os_env.update(env_params)

    if cwd is None:
        #set to home dir
        cwd = os.path.expanduser("~")
    print cwd + "=========="
    command.insert(0, "/usr/bin/git")
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=os_env, cwd=cwd)
    output, errors = p.communicate()
    if len(errors) > 0:
        raise RuntimeError("Command execution failed: \n %r" % errors)

    return output, errors

def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

#(output, errors) = execute_command(["status"], cwd="/var/www/www")
#print "output: " + output
#print "errors: " + errors

#st = output.split("\n\n")

#files = st[2].split("\n")

#for file_line in files:
#       file_name = file_line.split(":")
#       #print file_name
#       file_name = file_name[1].strip()
#       #print file_name

#uf = output.split("Untracked files")[1].split("\n\n")[1].split("\n\t")
#print uf
#for line in uf:
#       print line.strip()


#(output, errors) = execute_command(["add","--all"], cwd="/var/www/www")
#print "output: " + output
#print "errors: " + errors


(output, errors) = execute_command(["config","user.email", "user@example.com"], cwd="/var/www/www")
(output, errors) = execute_command(["config","user.name", "someuser"], cwd="/var/www/www")

#(output, errors) = execute_command(["commit","-m", "some commit message 1"], cwd="/var/www/www")
#print "output: " + output
#print "errors: " + errors

#commit_hash = find_between(output, "[master", "]")
#print commit_hash.strip()

(output, errors) = execute_command(["push", "origin", "master"], cwd="/var/www/www")
