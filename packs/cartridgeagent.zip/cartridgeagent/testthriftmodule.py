# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from modules.databridge.agent import *
import time

STREAM_NAME = "cartridge_agent_health_stats"
STREAM_VERSION = "1.0.0"
STREAM_NICKNAME = "agent health stats"
STREAM_DESCRIPTION = "agent health stats"


def create_stream_definition():
        """
        Create a StreamDefinition for publishing to CEP
        """
        stream_def = StreamDefinition()
        stream_def.name = STREAM_NAME
        stream_def.version = STREAM_VERSION
        stream_def.nickname = STREAM_NICKNAME
        stream_def.description = STREAM_DESCRIPTION

        stream_def.add_payloaddata_attribute("cluster_id", StreamDefinition.STRING)
        stream_def.add_payloaddata_attribute("network_partition_id", StreamDefinition.STRING)
        stream_def.add_payloaddata_attribute("member_id", StreamDefinition.STRING)
        stream_def.add_payloaddata_attribute("partition_id", StreamDefinition.STRING)
        stream_def.add_payloaddata_attribute("health_description", StreamDefinition.STRING)
        stream_def.add_payloaddata_attribute("value", StreamDefinition.DOUBLE)

        return stream_def


def get_event(value):
    event = ThriftEvent()
    event.payloadData.append("cluster_id")
    event.payloadData.append("network_partition_id")
    event.payloadData.append("member_id")
    event.payloadData.append("partition_id")
    event.payloadData.append("load_average")
    event.payloadData.append(value)

    return event


publisher = ThriftPublisher("172.17.8.1","7711","admin","admin",create_stream_definition())
event_n = 0
while True:
    time.sleep(15)
    publisher.publish(get_event(event_n))
    print "published event: %r" % event_n
    event_n += 1

